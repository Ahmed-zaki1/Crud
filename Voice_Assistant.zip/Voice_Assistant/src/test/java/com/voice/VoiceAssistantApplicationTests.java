package com.voice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoiceAssistantApplicationTests {

	@Test
	void contextLoads() {
	}

}
