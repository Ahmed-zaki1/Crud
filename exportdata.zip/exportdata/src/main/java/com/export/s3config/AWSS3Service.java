package com.export.s3config;

import java.io.File;

public interface AWSS3Service {

	 static String uploadFile(File file, String bucketName, String endPointUrl) {
		return null;
	}
	}


